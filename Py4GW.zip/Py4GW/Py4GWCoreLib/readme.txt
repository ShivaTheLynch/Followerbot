this is the Py4GWCoreLib main files.

do not modify this folder or files, it contains the core functionality 
of the Py4GWCoreLib.

if you want to modify the core functionality, you should
extend (inherit) functionality in your own private library.

